mcc   -m gremlin.m  -a minFunc/ -I misc/ -a LLM2 -I LLM2/mex     -R -singleCompThread 
