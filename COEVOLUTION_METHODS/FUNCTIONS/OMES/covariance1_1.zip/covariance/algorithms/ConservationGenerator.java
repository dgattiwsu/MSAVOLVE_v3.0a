package covariance.algorithms;

public interface ConservationGenerator
{
	public double getScore( int i ) throws Exception;
}
